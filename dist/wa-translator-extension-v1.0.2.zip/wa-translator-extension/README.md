# WhatsApp Send Translator

一个可在 Chrome / Edge 使用的 Manifest V3 浏览器插件。打开 WhatsApp Web 后，输入中文消息，插件会在发送前翻译为目标语言。

## 功能

- 支持 Chrome 和 Microsoft Edge。
- 支持 OpenAI 和 DeepSeek API。
- 可选择目标语言，也可选择不翻译。
- 自动检测中文：没有中文时直接发送。
- 两种发送模式：
  - 翻译后自动发送。
  - 只替换为译文，手动确认发送。
- 可选择是否附带中文原文。
- WhatsApp 输入区上方会显示两个按钮：
  - 目标语言下拉框：可直接在聊天界面切换发送译文的目标语言。
  - `发送原文`：不翻译，直接发送当前输入框内容。
  - `发送译文`：先翻译，再发送译文。
- 非中文聊天消息下方会显示 `翻译` 按钮，点击后把该消息翻译成中文并显示在原消息下面。

## 默认模型

- OpenAI：`gpt-5.5`
- DeepSeek：`deepseek-v4-flash`

你也可以在插件面板里改成其它模型名称。

## 安装到 Chrome

1. 打开 `chrome://extensions/`。
2. 打开右上角“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本文件夹：`wa-translator-extension`。
5. 打开 `https://web.whatsapp.com/`。
6. 点击浏览器右上角插件图标，填写 API Key、目标语言和发送模式。

## 安装到 Edge

1. 打开 `edge://extensions/`。
2. 打开左侧“开发人员模式”。
3. 点击“加载解压缩的扩展”。
4. 选择本文件夹：`wa-translator-extension`。
5. 打开 `https://web.whatsapp.com/` 并完成设置。

## 使用建议

- 第一次使用建议选择“只替换为译文，手动发送”，确认效果稳定后再切换到“翻译后自动发送”。
- API Key 保存在浏览器扩展的同步存储中。不要把整个插件文件夹和已导出的浏览器配置交给别人。
- WhatsApp Web 页面结构可能变化。如果未来发送拦截失效，需要更新 `content.js` 的选择器。

## 注意

这个插件只面向你本人正常聊天使用，不应做群发、刷屏、营销自动化或绕过 WhatsApp 风控的用途。
